/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author User
 */
public class CartItem {
    private String prodID;
    private String prodName;
    private String size;
    private double price;
    private int quantity;
private double ttl;
    public CartItem(){
     
    }
    
    public CartItem(String prodID, String prodName, String size, double price, int quantity, double ttl) {
        this.prodID = prodID;
        this.prodName = prodName;
        this.size = size;
        this.price = price;
        this.quantity = quantity;
        this.ttl=ttl;
    }

    public String getProdID() {
        return prodID;
    }

    public void setProdID(String prodID) {
        this.prodID = prodID;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public double getTtl() {
        return ttl;
    }

    public void setTtl(double ttl) {
        this.ttl = ttl;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public double getTotalPrice(){
        return price*quantity;
    }
    
}
