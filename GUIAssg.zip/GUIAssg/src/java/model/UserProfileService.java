/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import entity.Customer;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
/**
 *
 * @author User
 */
public class UserProfileService {
  @PersistenceContext
    EntityManager mgr;
    @Resource
    Query query;   
    public UserProfileService(EntityManager mgr) {
        this.mgr = mgr;
    }

    public boolean addCust(Customer customer) {
        mgr.persist(customer);
        return true;
    }

    public Customer findCustByCustid(String custid) {
        Customer customer = mgr.find(Customer.class, custid);
        return customer;
    }

    public boolean deleteCust(String custid) {
        Customer customer = findCustByCustid(custid);
        if (customer != null) {
            mgr.remove(customer);
            return true;
        }
        return false;
    }

    public List<Customer> findAll() {
        List itemList = mgr.createNamedQuery("Customer.findAll").getResultList();
        return itemList;
    }

    public boolean updateCustomer(Customer customer) {
        Customer tempItem = findCustByCustid(customer.getCustid());
        if (tempItem != null) {
            tempItem.setCustid(customer.getCustid());
//            tempItem.setCustname(customer.getCustname());
            tempItem.setCusthpnum(customer.getCusthpnum());
            tempItem.setCustemail(customer.getCustemail());
            tempItem.setCustpassword(customer.getCustpassword());
            tempItem.setCustaddress(customer.getCustaddress());
//            tempItem.setCustgender(customer.getCustgender());
            tempItem.setCustprofilepic(customer.getCustprofilepic());
            System.out.println(tempItem);
            return true;
            
        }
        return false;
    }
}
