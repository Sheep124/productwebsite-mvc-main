/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author User
 */
@Entity
@Table(name = "CARDDETAILS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Carddetails.findAll", query = "SELECT c FROM Carddetails c"),
    @NamedQuery(name = "Carddetails.findByCardid", query = "SELECT c FROM Carddetails c WHERE c.cardid = :cardid"),
    @NamedQuery(name = "Carddetails.findByCardholdername", query = "SELECT c FROM Carddetails c WHERE c.cardholdername = :cardholdername"),
    @NamedQuery(name = "Carddetails.findByCardcvv", query = "SELECT c FROM Carddetails c WHERE c.cardcvv = :cardcvv"),
    @NamedQuery(name = "Carddetails.findByCardexpireddate", query = "SELECT c FROM Carddetails c WHERE c.cardexpireddate = :cardexpireddate"),
    @NamedQuery(name = "Carddetails.findByCardtype", query = "SELECT c FROM Carddetails c WHERE c.cardtype = :cardtype"),
    @NamedQuery(name = "Carddetails.findByCardactive", query = "SELECT c FROM Carddetails c WHERE c.cardactive = :cardactive"),
    @NamedQuery(name = "Carddetails.findByCardcreated", query = "SELECT c FROM Carddetails c WHERE c.cardcreated = :cardcreated")})
public class Carddetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 17)
    @Column(name = "CARDID")
    private String cardid;
    @Size(max = 50)
    @Column(name = "CARDHOLDERNAME")
    private String cardholdername;
    @Size(max = 4)
    @Column(name = "CARDCVV")
    private String cardcvv;
    @Size(max = 6)
    @Column(name = "CARDEXPIREDDATE")
    private String cardexpireddate;
    @Size(max = 20)
    @Column(name = "CARDTYPE")
    private String cardtype;
    @Column(name = "CARDACTIVE")
    private Character cardactive;
    @Column(name = "CARDCREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date cardcreated;
    @JoinColumn(name = "CUSTID", referencedColumnName = "CUSTID")
    @ManyToOne
    private Customer custid;

    public Carddetails() {
    }

    public Carddetails(String cardid) {
        this.cardid = cardid;
    }

    public String getCardid() {
        return cardid;
    }

    public void setCardid(String cardid) {
        this.cardid = cardid;
    }

    public String getCardholdername() {
        return cardholdername;
    }

    public void setCardholdername(String cardholdername) {
        this.cardholdername = cardholdername;
    }

    public String getCardcvv() {
        return cardcvv;
    }

    public void setCardcvv(String cardcvv) {
        this.cardcvv = cardcvv;
    }

    public String getCardexpireddate() {
        return cardexpireddate;
    }

    public void setCardexpireddate(String cardexpireddate) {
        this.cardexpireddate = cardexpireddate;
    }

    public String getCardtype() {
        return cardtype;
    }

    public void setCardtype(String cardtype) {
        this.cardtype = cardtype;
    }

    public Character getCardactive() {
        return cardactive;
    }

    public void setCardactive(Character cardactive) {
        this.cardactive = cardactive;
    }

    public Date getCardcreated() {
        return cardcreated;
    }

    public void setCardcreated(Date cardcreated) {
        this.cardcreated = cardcreated;
    }

    public Customer getCustid() {
        return custid;
    }

    public void setCustid(Customer custid) {
        this.custid = custid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cardid != null ? cardid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Carddetails)) {
            return false;
        }
        Carddetails other = (Carddetails) object;
        if ((this.cardid == null && other.cardid != null) || (this.cardid != null && !this.cardid.equals(other.cardid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Carddetails[ cardid=" + cardid + " ]";
    }
    
}
