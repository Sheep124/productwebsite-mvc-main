/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import entity.Customer;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;
import model.UserProfileService;

/**
 *
 * @author User
 */
@WebServlet(name = "UserReg", urlPatterns = {"/UserReg"})
public class UserReg extends HttpServlet {
 @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            int rowCount = em.createNamedQuery("Customer.findAll").getResultList().size();
            System.out.println(rowCount);
            String newCustId = "C" + (rowCount + 1);
            String custname = request.getParameter("custname");
            String custhpnum = request.getParameter("custhpnum");
            String custemail = request.getParameter("custemail");
            String custpassword = request.getParameter("custpassword");

            // encrypt the user password before storing it in the database
            encrytion encryption = new encrytion(custpassword);
            String encryptedPassword = encryption.encryt();
            String custaddress = request.getParameter("custaddress");
            String custgender = request.getParameter("custgender");
            String custprofilepic = request.getParameter("custprofilepic");
            System.out.println("encryptedpass" + encryptedPassword);
            Customer customer = new Customer(newCustId, custname, custhpnum, custemail, encryptedPassword, custaddress, custgender, custprofilepic);

            customer.setCustcreateddate(new Date());
            customer.setCustrecentlogin(new Date());

            UserProfileService itemService = new UserProfileService(em);
            utx.begin();
            boolean success = itemService.addCust(customer);
            utx.commit();
            HttpSession session = request.getSession();
            session.setAttribute("success", success);
            session.setAttribute("custid", customer.getCustid());
            session.setAttribute("custpass", custpassword);

            session.setAttribute("custrecentlogin", new Date());
            session.setAttribute("loggedIn", true);
            Cookie cookie = new Cookie("custid", String.valueOf(customer.getCustid())); // create custid cookie
            cookie.setMaxAge(3600); // set cookie expiration time to 1 hour
            response.addCookie(cookie); // add cookie to the response
            response.sendRedirect("RegConfirm.jsp");
        } catch (Exception ex) {
            Logger.getLogger(UserReg.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet UserReg</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet UserReg at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
