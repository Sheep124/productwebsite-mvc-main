/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.*;

/**
 *
 * @author User
 */
public class Cart {
    private List<CartItem> items;
    private double[] ttl;
    public Cart(){
        items = new ArrayList<CartItem>();
    }
    
    public void addItem(CartItem item){
        items.add(item);
    }
    
    public CartItem findItem(String prodID, String size) {
    for (CartItem item : items) {
        if (item.getProdID().equals(prodID) && item.getSize().equals(size)) {
            return item;
        }
    }
    
    return null;
}
   
    public int updateItem(String prodID, int qty){
        int q=0;
      //  double ttl=0;
        for(CartItem item:items){
            if(item.getProdID().equals(prodID)){
                item.setQuantity(qty);
                q=item.getQuantity();
               
                break;
                
            }
            
        }
     
        return q;
    }
    
    public void removeItem(String prodID){
        for(int i=0;i<items.size();i++){
            if(items.get(i).getProdID().equals(prodID)){
                items.remove(i);
                break;
            }
        }
      
        
    }
    
    public List<CartItem> getItems(){
        return items;
    }
    
    public double getSubTotalPrice(){
        double price=0;
        for(CartItem item:items){
            price+=item.getTotalPrice();
        }
        return price;
    }
    
    public double getShippingFee(){
        double ship=0;
        if(getSubTotalPrice()>0&&getSubTotalPrice()< 200){
            ship=25;
        }
        else
            ship=0;
        return ship;
    }
    
    public double getTotalFee(){
        
        double ttl=getSubTotalPrice()+getShippingFee();
        return ttl;
    }
    
    public int getSubTotalQuantity(){
        int qty=0;
        for(CartItem item:items){
            qty+=item.getQuantity();
        }
        return qty; 
    }
}
