/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author User
 */
@Entity
@Table(name = "STATUS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Status.findAll", query = "SELECT s FROM Status s"),
    @NamedQuery(name = "Status.findBySeqno", query = "SELECT s FROM Status s WHERE s.seqno = :seqno"),
    @NamedQuery(name = "Status.findByStatusname", query = "SELECT s FROM Status s WHERE s.statusname = :statusname")})
public class Status implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "SEQNO")
    private Integer seqno;
    @Size(max = 30)
    @Column(name = "STATUSNAME")
    private String statusname;

    public Status() {
    }

    public Status(Integer seqno) {
        this.seqno = seqno;
    }

    public Integer getSeqno() {
        return seqno;
    }

    public void setSeqno(Integer seqno) {
        this.seqno = seqno;
    }

    public String getStatusname() {
        return statusname;
    }

    public void setStatusname(String statusname) {
        this.statusname = statusname;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (seqno != null ? seqno.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Status)) {
            return false;
        }
        Status other = (Status) object;
        if ((this.seqno == null && other.seqno != null) || (this.seqno != null && !this.seqno.equals(other.seqno))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Status[ seqno=" + seqno + " ]";
    }
    
}
