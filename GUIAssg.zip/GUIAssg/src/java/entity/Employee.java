/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "EMPLOYEE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Employee.findAll", query = "SELECT e FROM Employee e"),
    @NamedQuery(name = "Employee.findByEmpid", query = "SELECT e FROM Employee e WHERE e.empid = :empid"),
    @NamedQuery(name = "Employee.findByEmprecentlogin", query = "SELECT e FROM Employee e WHERE e.emprecentlogin = :emprecentlogin"),
    @NamedQuery(name = "Employee.findByEmpstatus", query = "SELECT e FROM Employee e WHERE e.empstatus = :empstatus"),
    @NamedQuery(name = "Employee.findByEmpactive", query = "SELECT e FROM Employee e WHERE e.empactive = :empactive"),
    @NamedQuery(name = "Employee.findByEmpname", query = "SELECT e FROM Employee e WHERE e.empname = :empname"),
    @NamedQuery(name = "Employee.findByEmphpnum", query = "SELECT e FROM Employee e WHERE e.emphpnum = :emphpnum"),
    @NamedQuery(name = "Employee.findByEmpemail", query = "SELECT e FROM Employee e WHERE e.empemail = :empemail"),
    @NamedQuery(name = "Employee.findByEmpaddress", query = "SELECT e FROM Employee e WHERE e.empaddress = :empaddress"),
    @NamedQuery(name = "Employee.findByEmpgender", query = "SELECT e FROM Employee e WHERE e.empgender = :empgender"),
    @NamedQuery(name = "Employee.findByEmppassword", query = "SELECT e FROM Employee e WHERE e.emppassword = :emppassword"),
    @NamedQuery(name = "Employee.findByEmpsignup", query = "SELECT e FROM Employee e WHERE e.empsignup = :empsignup"),
    @NamedQuery(name = "Employee.findByEmpcreated", query = "SELECT e FROM Employee e WHERE e.empcreated = :empcreated")})
public class Employee implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "EMPID")
    private String empid;
    @Size(max = 10)
    @Column(name = "EMPRECENTLOGIN")
    private String emprecentlogin;
    @Size(max = 20)
    @Column(name = "EMPSTATUS")
    private String empstatus;
    @Column(name = "EMPACTIVE")
    private Character empactive;
    @Size(max = 50)
    @Column(name = "EMPNAME")
    private String empname;
    @Size(max = 12)
    @Column(name = "EMPHPNUM")
    private String emphpnum;
    @Size(max = 30)
    @Column(name = "EMPEMAIL")
    private String empemail;
    @Size(max = 100)
    @Column(name = "EMPADDRESS")
    private String empaddress;
    @Column(name = "EMPGENDER")
    private Character empgender;
    @Lob
    @Column(name = "EMPPROFILEPIC")
    private Serializable empprofilepic;
    @Size(max = 20)
    @Column(name = "EMPPASSWORD")
    private String emppassword;
    @Size(max = 10)
    @Column(name = "EMPSIGNUP")
    private String empsignup;
    @Column(name = "EMPCREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date empcreated;
    @JoinColumn(name = "EMPPERMISSION", referencedColumnName = "PERMISSIONID")
    @ManyToOne
    private Permissionlevel emppermission;
    @OneToMany(mappedBy = "empid")
    private List<Orders> ordersList;
    @OneToMany(mappedBy = "empid")
    private List<Annoucement> annoucementList;

    public Employee() {
    }

    public Employee(String empid) {
        this.empid = empid;
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getEmprecentlogin() {
        return emprecentlogin;
    }

    public void setEmprecentlogin(String emprecentlogin) {
        this.emprecentlogin = emprecentlogin;
    }

    public String getEmpstatus() {
        return empstatus;
    }

    public void setEmpstatus(String empstatus) {
        this.empstatus = empstatus;
    }

    public Character getEmpactive() {
        return empactive;
    }

    public void setEmpactive(Character empactive) {
        this.empactive = empactive;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getEmphpnum() {
        return emphpnum;
    }

    public void setEmphpnum(String emphpnum) {
        this.emphpnum = emphpnum;
    }

    public String getEmpemail() {
        return empemail;
    }

    public void setEmpemail(String empemail) {
        this.empemail = empemail;
    }

    public String getEmpaddress() {
        return empaddress;
    }

    public void setEmpaddress(String empaddress) {
        this.empaddress = empaddress;
    }

    public Character getEmpgender() {
        return empgender;
    }

    public void setEmpgender(Character empgender) {
        this.empgender = empgender;
    }

    public Serializable getEmpprofilepic() {
        return empprofilepic;
    }

    public void setEmpprofilepic(Serializable empprofilepic) {
        this.empprofilepic = empprofilepic;
    }

    public String getEmppassword() {
        return emppassword;
    }

    public void setEmppassword(String emppassword) {
        this.emppassword = emppassword;
    }

    public String getEmpsignup() {
        return empsignup;
    }

    public void setEmpsignup(String empsignup) {
        this.empsignup = empsignup;
    }

    public Date getEmpcreated() {
        return empcreated;
    }

    public void setEmpcreated(Date empcreated) {
        this.empcreated = empcreated;
    }

    public Permissionlevel getEmppermission() {
        return emppermission;
    }

    public void setEmppermission(Permissionlevel emppermission) {
        this.emppermission = emppermission;
    }

    @XmlTransient
    public List<Orders> getOrdersList() {
        return ordersList;
    }

    public void setOrdersList(List<Orders> ordersList) {
        this.ordersList = ordersList;
    }

    @XmlTransient
    public List<Annoucement> getAnnoucementList() {
        return annoucementList;
    }

    public void setAnnoucementList(List<Annoucement> annoucementList) {
        this.annoucementList = annoucementList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (empid != null ? empid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Employee)) {
            return false;
        }
        Employee other = (Employee) object;
        if ((this.empid == null && other.empid != null) || (this.empid != null && !this.empid.equals(other.empid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Employee[ empid=" + empid + " ]";
    }
    
}
