/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author User
 */
@Entity
@Table(name = "INVENTORY")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Inventory.findAll", query = "SELECT i FROM Inventory i"),
    @NamedQuery(name = "Inventory.findByInventoryid", query = "SELECT i FROM Inventory i WHERE i.inventoryid = :inventoryid"),
    @NamedQuery(name = "Inventory.findByInvensize", query = "SELECT i FROM Inventory i WHERE i.invensize = :invensize"),
    @NamedQuery(name = "Inventory.findByInvenquantity", query = "SELECT i FROM Inventory i WHERE i.invenquantity = :invenquantity"),
    @NamedQuery(name = "Inventory.findByInvencreated", query = "SELECT i FROM Inventory i WHERE i.invencreated = :invencreated")})
public class Inventory implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "INVENTORYID")
    private Integer inventoryid;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "INVENSIZE")
    private BigDecimal invensize;
    @Column(name = "INVENQUANTITY")
    private Integer invenquantity;
    @Column(name = "INVENCREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date invencreated;
    @JoinColumn(name = "PRODID", referencedColumnName = "PRODID")
    @ManyToOne
    private Product prodid;

    public Inventory() {
    }

    public Inventory(Integer inventoryid) {
        this.inventoryid = inventoryid;
    }

    public Integer getInventoryid() {
        return inventoryid;
    }

    public void setInventoryid(Integer inventoryid) {
        this.inventoryid = inventoryid;
    }

    public BigDecimal getInvensize() {
        return invensize;
    }

    public void setInvensize(BigDecimal invensize) {
        this.invensize = invensize;
    }

    public Integer getInvenquantity() {
        return invenquantity;
    }

    public void setInvenquantity(Integer invenquantity) {
        this.invenquantity = invenquantity;
    }

    public Date getInvencreated() {
        return invencreated;
    }

    public void setInvencreated(Date invencreated) {
        this.invencreated = invencreated;
    }

    public Product getProdid() {
        return prodid;
    }

    public void setProdid(Product prodid) {
        this.prodid = prodid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (inventoryid != null ? inventoryid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Inventory)) {
            return false;
        }
        Inventory other = (Inventory) object;
        if ((this.inventoryid == null && other.inventoryid != null) || (this.inventoryid != null && !this.inventoryid.equals(other.inventoryid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Inventory[ inventoryid=" + inventoryid + " ]";
    }
    
}
