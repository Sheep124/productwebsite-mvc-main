/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;
import model.Cart;
import model.CartItem;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author User
 */
@WebServlet(name = "CartServlet", urlPatterns = {"/CartServlet"})
public class CartServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {HttpSession sess = request.getSession();
        String prodID = request.getParameter("prodID");
       //if cart is clicked without selecting any product
        if(prodID==null||prodID.equals("")){
            sess.setAttribute("message1", "Please add items to the cart first.");
    response.sendRedirect("Cart.jsp");
    
    return;
        }
        //if click add to cart without selecting size
        String size = request.getParameter("size");
        if(size==null||size.equals("")){
            //request.setAttribute("message2", "Please select a size");
            response.sendRedirect("sizeEmpty.html");
            return;
            
        }

        String prodName = request.getParameter("prodName");
        String prodPrice = request.getParameter("prodPrice");
        double price = Double.parseDouble(prodPrice);
        
        Cart cart=(Cart) sess.getAttribute("cart");
        try{
        if(cart==null){
            cart = new Cart();
            sess.setAttribute("cart", cart);
        }
        CartItem existingItem = cart.findItem(prodID, size);

        if(existingItem != null) {
    // product already exists in the cart, update the quantity
            int newQuantity = existingItem.getQuantity() + 1;
            existingItem.setQuantity(newQuantity);
            
        } else {
            CartItem item = new CartItem(prodID,prodName,size,price,1,price);
            cart.addItem(item);
        //cart.itemPrice(prodID);
}
       
        }catch(Exception ex){
            
        }
        response.sendRedirect("addConfirm.html");        
        response.setContentType("text/html;charset=UTF-8");
        
            
        
            
    }

   // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
