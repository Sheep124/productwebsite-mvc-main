/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "PROMOTION")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Promotion.findAll", query = "SELECT p FROM Promotion p"),
    @NamedQuery(name = "Promotion.findByPromotionid", query = "SELECT p FROM Promotion p WHERE p.promotionid = :promotionid"),
    @NamedQuery(name = "Promotion.findByPromotiondescription", query = "SELECT p FROM Promotion p WHERE p.promotiondescription = :promotiondescription"),
    @NamedQuery(name = "Promotion.findByPromotiondiscount", query = "SELECT p FROM Promotion p WHERE p.promotiondiscount = :promotiondiscount"),
    @NamedQuery(name = "Promotion.findByPromotionstart", query = "SELECT p FROM Promotion p WHERE p.promotionstart = :promotionstart"),
    @NamedQuery(name = "Promotion.findByPromotionend", query = "SELECT p FROM Promotion p WHERE p.promotionend = :promotionend"),
    @NamedQuery(name = "Promotion.findByPromotionquantity", query = "SELECT p FROM Promotion p WHERE p.promotionquantity = :promotionquantity"),
    @NamedQuery(name = "Promotion.findByPromotioncreated", query = "SELECT p FROM Promotion p WHERE p.promotioncreated = :promotioncreated")})
public class Promotion implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "PROMOTIONID")
    private String promotionid;
    @Size(max = 50)
    @Column(name = "PROMOTIONDESCRIPTION")
    private String promotiondescription;
    @Column(name = "PROMOTIONDISCOUNT")
    private Integer promotiondiscount;
    @Column(name = "PROMOTIONSTART")
    @Temporal(TemporalType.DATE)
    private Date promotionstart;
    @Column(name = "PROMOTIONEND")
    @Temporal(TemporalType.DATE)
    private Date promotionend;
    @Column(name = "PROMOTIONQUANTITY")
    private Integer promotionquantity;
    @Column(name = "PROMOTIONCREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date promotioncreated;
    @OneToMany(mappedBy = "promotionid")
    private List<Payment> paymentList;

    public Promotion() {
    }

    public Promotion(String promotionid) {
        this.promotionid = promotionid;
    }

    public String getPromotionid() {
        return promotionid;
    }

    public void setPromotionid(String promotionid) {
        this.promotionid = promotionid;
    }

    public String getPromotiondescription() {
        return promotiondescription;
    }

    public void setPromotiondescription(String promotiondescription) {
        this.promotiondescription = promotiondescription;
    }

    public Integer getPromotiondiscount() {
        return promotiondiscount;
    }

    public void setPromotiondiscount(Integer promotiondiscount) {
        this.promotiondiscount = promotiondiscount;
    }

    public Date getPromotionstart() {
        return promotionstart;
    }

    public void setPromotionstart(Date promotionstart) {
        this.promotionstart = promotionstart;
    }

    public Date getPromotionend() {
        return promotionend;
    }

    public void setPromotionend(Date promotionend) {
        this.promotionend = promotionend;
    }

    public Integer getPromotionquantity() {
        return promotionquantity;
    }

    public void setPromotionquantity(Integer promotionquantity) {
        this.promotionquantity = promotionquantity;
    }

    public Date getPromotioncreated() {
        return promotioncreated;
    }

    public void setPromotioncreated(Date promotioncreated) {
        this.promotioncreated = promotioncreated;
    }

    @XmlTransient
    public List<Payment> getPaymentList() {
        return paymentList;
    }

    public void setPaymentList(List<Payment> paymentList) {
        this.paymentList = paymentList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (promotionid != null ? promotionid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Promotion)) {
            return false;
        }
        Promotion other = (Promotion) object;
        if ((this.promotionid == null && other.promotionid != null) || (this.promotionid != null && !this.promotionid.equals(other.promotionid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Promotion[ promotionid=" + promotionid + " ]";
    }
    
}
