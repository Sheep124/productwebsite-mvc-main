/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author User
 */
@Entity
@Table(name = "ANNOUCEMENT")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Annoucement.findAll", query = "SELECT a FROM Annoucement a"),
    @NamedQuery(name = "Annoucement.findByAnnoucementid", query = "SELECT a FROM Annoucement a WHERE a.annoucementid = :annoucementid"),
    @NamedQuery(name = "Annoucement.findByReleasedate", query = "SELECT a FROM Annoucement a WHERE a.releasedate = :releasedate"),
    @NamedQuery(name = "Annoucement.findByTitle", query = "SELECT a FROM Annoucement a WHERE a.title = :title"),
    @NamedQuery(name = "Annoucement.findByBody", query = "SELECT a FROM Annoucement a WHERE a.body = :body")})
public class Annoucement implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ANNOUCEMENTID")
    private Integer annoucementid;
    @Size(max = 10)
    @Column(name = "RELEASEDATE")
    private String releasedate;
    @Size(max = 100)
    @Column(name = "TITLE")
    private String title;
    @Size(max = 1000)
    @Column(name = "BODY")
    private String body;
    @Lob
    @Column(name = "PICTURE")
    private Serializable picture;
    @JoinColumn(name = "EMPID", referencedColumnName = "EMPID")
    @ManyToOne
    private Employee empid;

    public Annoucement() {
    }

    public Annoucement(Integer annoucementid) {
        this.annoucementid = annoucementid;
    }

    public Integer getAnnoucementid() {
        return annoucementid;
    }

    public void setAnnoucementid(Integer annoucementid) {
        this.annoucementid = annoucementid;
    }

    public String getReleasedate() {
        return releasedate;
    }

    public void setReleasedate(String releasedate) {
        this.releasedate = releasedate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public Serializable getPicture() {
        return picture;
    }

    public void setPicture(Serializable picture) {
        this.picture = picture;
    }

    public Employee getEmpid() {
        return empid;
    }

    public void setEmpid(Employee empid) {
        this.empid = empid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (annoucementid != null ? annoucementid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Annoucement)) {
            return false;
        }
        Annoucement other = (Annoucement) object;
        if ((this.annoucementid == null && other.annoucementid != null) || (this.annoucementid != null && !this.annoucementid.equals(other.annoucementid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Annoucement[ annoucementid=" + annoucementid + " ]";
    }
    
}
