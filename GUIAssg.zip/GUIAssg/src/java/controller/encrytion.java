/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Logger;
/**
 *
 * @author User
 */
public class encrytion {
    private String task = "security";
    private String password;

    public encrytion() {
    }

    public encrytion(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String encryt() {

        try {
            MessageDigest m = MessageDigest.getInstance("MD5");
            m.update(password.getBytes());

            byte[] bytes = m.digest();

            StringBuilder s = new StringBuilder();
            for (int i = 0; i < bytes.length; i++) {
                s.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }

            /* Complete hashed password in hexadecimal format */
            password = s.toString();

        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(task + " error : " + ex);
        }

       System.out.println(task + " before : " + password);
        password = String.format("%." + 20 + "s", password);
        System.out.println(task + " after: " + password);

        return password;
    }

    public static void main(String[] args) {
        encrytion en = new encrytion("kenneth");
        System.out.println("encryted pass = " + en.encryt());
    }
}
