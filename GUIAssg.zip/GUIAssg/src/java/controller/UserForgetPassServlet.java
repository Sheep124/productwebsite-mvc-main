/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import controller.UserReg;
import entity.Customer;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;
/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/UserForgetPassServlet"})
public class UserForgetPassServlet extends HttpServlet {

    @PersistenceContext
    EntityManager em;
    @Resource
    UserTransaction utx;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        try {
            String custemail = request.getParameter("custemail");
            // perform validation checks for the email here
            Customer customer = em.createQuery("SELECT c FROM Customer c WHERE c.custemail = :custemail", Customer.class)
                    .setParameter("custemail", custemail)
                    .getSingleResult();
            System.out.println(customer.getCustpassword());
            if (custemail.trim().equals(customer.getCustemail().trim())) {
                // generate a new password
                String custname = customer.getCustname();
                String custpassword = generatePassword();
                encrytion enc = new encrytion(custpassword);
                String encryptedPassword = enc.encryt();
                customer.setCustpassword(encryptedPassword);
                utx.begin();
                em.merge(customer);
                // update the password for the user in your database here
                System.out.println(customer);
                System.out.println(customer.getCustpassword());
                utx.commit();
                // send an email to the user with the new password
                sendEmail(custemail, custpassword, custname);
                session.invalidate();
                response.sendRedirect("UserResetPassSuccess.jsp");
            } else {
                session.setAttribute("error", "Invalid Username or Password");
                response.sendRedirect("loginError.html");
            }
        } catch (Exception ex) {
            Logger.getLogger(UserReg.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException(ex);
        }
    }
    
    
     private String generatePassword() {
        // generate a random password and return it here
        Random random = new Random();
        int randomNumber = random.nextInt(10000000); // generates a random number between 0 (inclusive) and 1000 (exclusive)
        return String.valueOf(randomNumber);
    }

         private void sendEmail(String custemail, String custpassword, String custname) {
        // Set the email properties
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        // Create a new session with an authenticator
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("chuas-wm21@student.tarc.edu.my", "Shihui@22");
            }
        });

        try {
            // Create a new email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("custemail"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(custemail));
            message.setSubject("Your new temporary password");
            message.setText("Dear " + custname + ",\n\nYour new temporary password for your account is: " + custpassword
                    + ". You can now login with this password and update a new password when you go to profile page");

            // Send the email message
            Transport.send(message);
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }
         
  // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

