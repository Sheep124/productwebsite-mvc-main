/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "PRODUCT")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Product.findAll", query = "SELECT p FROM Product p"),
    @NamedQuery(name = "Product.findByProdid", query = "SELECT p FROM Product p WHERE p.prodid = :prodid"),
    @NamedQuery(name = "Product.findByProdname", query = "SELECT p FROM Product p WHERE p.prodname = :prodname"),
    @NamedQuery(name = "Product.findByProdprice", query = "SELECT p FROM Product p WHERE p.prodprice = :prodprice"),
    @NamedQuery(name = "Product.findByProddescription", query = "SELECT p FROM Product p WHERE p.proddescription = :proddescription"),
    @NamedQuery(name = "Product.findByProdcategory", query = "SELECT p FROM Product p WHERE p.prodcategory = :prodcategory"),
    @NamedQuery(name = "Product.findByProdcreated", query = "SELECT p FROM Product p WHERE p.prodcreated = :prodcreated")})
public class Product implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 11)
    @Column(name = "PRODID")
    private String prodid;
    @Size(max = 50)
    @Column(name = "PRODNAME")
    private String prodname;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "PRODPRICE")
    private double prodprice;
    @Size(max = 50)
    @Column(name = "PRODDESCRIPTION")
    private String proddescription;
    @Size(max = 50)
    @Column(name = "PRODCATEGORY")
    private String prodcategory;
    @Lob
    @Column(name = "PRODPIC")
    private String prodpic; //orgn Serializable
    @Column(name = "PRODCREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date prodcreated;
    @OneToMany(mappedBy = "prodid")
    private List<Inventory> inventoryList;
    @OneToMany(mappedBy = "prodid")
    private List<Orderdetails> orderdetailsList;

    public Product() {
    }

    public Product(String prodid) {
        this.prodid = prodid;
    }

    public String getProdid() {
        return prodid;
    }

    public void setProdid(String prodid) {
        this.prodid = prodid;
    }

    public String getProdname() {
        return prodname;
    }

    public void setProdname(String prodname) {
        this.prodname = prodname;
    }

    public double getProdprice() {
        return prodprice;
    }

    public void setProdprice(double prodprice) {
        this.prodprice = prodprice;
    }

    public String getProddescription() {
        return proddescription;
    }

    public void setProddescription(String proddescription) {
        this.proddescription = proddescription;
    }

    public String getProdcategory() {
        return prodcategory;
    }

    public void setProdcategory(String prodcategory) {
        this.prodcategory = prodcategory;
    }

    public String getProdpic() {
        return prodpic;
    }
    

    public void setProdpic(String prodpic) {
        this.prodpic = prodpic;
    }

    public Date getProdcreated() {
        return prodcreated;
    }

    public void setProdcreated(Date prodcreated) {
        this.prodcreated = prodcreated;
    }

    @XmlTransient
    public List<Inventory> getInventoryList() {
        return inventoryList;
    }

    public void setInventoryList(List<Inventory> inventoryList) {
        this.inventoryList = inventoryList;
    }

    @XmlTransient
    public List<Orderdetails> getOrderdetailsList() {
        return orderdetailsList;
    }

    public void setOrderdetailsList(List<Orderdetails> orderdetailsList) {
        this.orderdetailsList = orderdetailsList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (prodid != null ? prodid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Product)) {
            return false;
        }
        Product other = (Product) object;
        if ((this.prodid == null && other.prodid != null) || (this.prodid != null && !this.prodid.equals(other.prodid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Product[ prodid=" + prodid + " ]";
    }
    
}
