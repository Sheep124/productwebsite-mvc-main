/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author User
 */
@Entity
@Table(name = "ORDERDETAILS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Orderdetails.findAll", query = "SELECT o FROM Orderdetails o"),
    @NamedQuery(name = "Orderdetails.findByOrderdetailid", query = "SELECT o FROM Orderdetails o WHERE o.orderdetailid = :orderdetailid"),
    @NamedQuery(name = "Orderdetails.findByProdsize", query = "SELECT o FROM Orderdetails o WHERE o.prodsize = :prodsize"),
    @NamedQuery(name = "Orderdetails.findByProdprice", query = "SELECT o FROM Orderdetails o WHERE o.prodprice = :prodprice"),
    @NamedQuery(name = "Orderdetails.findByQuantity", query = "SELECT o FROM Orderdetails o WHERE o.quantity = :quantity"),
    @NamedQuery(name = "Orderdetails.findByOrderdetailscreated", query = "SELECT o FROM Orderdetails o WHERE o.orderdetailscreated = :orderdetailscreated")})
public class Orderdetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "ORDERDETAILID")
    private String orderdetailid;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "PRODSIZE")
    private BigDecimal prodsize;
    @Column(name = "PRODPRICE")
    private BigDecimal prodprice;
    @Column(name = "QUANTITY")
    private Integer quantity;
    @Column(name = "ORDERDETAILSCREATED")
    @Temporal(TemporalType.TIMESTAMP)
    private Date orderdetailscreated;
    @JoinColumn(name = "ORDERID", referencedColumnName = "ORDERID")
    @ManyToOne
    private Orders orderid;
    @JoinColumn(name = "PRODID", referencedColumnName = "PRODID")
    @ManyToOne
    private Product prodid;

    public Orderdetails() {
    }

    public Orderdetails(String orderdetailid) {
        this.orderdetailid = orderdetailid;
    }

    public String getOrderdetailid() {
        return orderdetailid;
    }

    public void setOrderdetailid(String orderdetailid) {
        this.orderdetailid = orderdetailid;
    }

    public BigDecimal getProdsize() {
        return prodsize;
    }

    public void setProdsize(BigDecimal prodsize) {
        this.prodsize = prodsize;
    }

    public BigDecimal getProdprice() {
        return prodprice;
    }

    public void setProdprice(BigDecimal prodprice) {
        this.prodprice = prodprice;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Date getOrderdetailscreated() {
        return orderdetailscreated;
    }

    public void setOrderdetailscreated(Date orderdetailscreated) {
        this.orderdetailscreated = orderdetailscreated;
    }

    public Orders getOrderid() {
        return orderid;
    }

    public void setOrderid(Orders orderid) {
        this.orderid = orderid;
    }

    public Product getProdid() {
        return prodid;
    }

    public void setProdid(Product prodid) {
        this.prodid = prodid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (orderdetailid != null ? orderdetailid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Orderdetails)) {
            return false;
        }
        Orderdetails other = (Orderdetails) object;
        if ((this.orderdetailid == null && other.orderdetailid != null) || (this.orderdetailid != null && !this.orderdetailid.equals(other.orderdetailid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Orderdetails[ orderdetailid=" + orderdetailid + " ]";
    }
    
}
