/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import entity.Orders;
import java.io.IOException;
import java.io.PrintWriter;
import javax.annotation.Resource;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;

/**
 *
 * @author User
 */
@WebServlet(name = "OrderStatusChange", urlPatterns = {"/OrderStatusChange"})
@TransactionManagement(TransactionManagementType.BEAN)
public class OrderStatusChange extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Resource
    private UserTransaction utx;

    @PersistenceContext
    private EntityManager em;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       // Get the order ID and button clicked from the request parameters
        String orderid = request.getParameter("orderid");
        System.out.println(orderid);
        String buttonClicked = request.getParameter("buttonClicked");
        System.out.println(buttonClicked);

// Find the order with the given ID in the database
        Orders order = em.find(Orders.class, orderid);
        System.out.println(order);
        // Update the order status based on the button clicked
        if (buttonClicked.contains("OrderReceived")) {
            order.setOrderstatus("Completed");
        } else if (buttonClicked.contains("RequestRefund")) {
            order.setOrderstatus("Pending Return&Refund");
        } else if (buttonClicked.contains("RequestCancel")) {
            order.setOrderstatus("Pending Cancel");
        } else if (buttonClicked.contains("CancelRefundRequest")) {
            order.setOrderstatus("Shipped");
        } else if (buttonClicked.contains("CancelCancelRequest")) {
            order.setOrderstatus("Confirmed");
        }
        try {
            utx.begin();
            em.merge(order);
            utx.commit();
        } catch (Exception e) {
            try {
                utx.rollback();
            } catch (Exception ex) {
                throw new ServletException(ex);
            }
            throw new ServletException(e);
        }

        // Redirect the user back to the order page
        response.sendRedirect("OrderStatusChangeConfirm.jsp");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
