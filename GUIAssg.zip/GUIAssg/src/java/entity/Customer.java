/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "CUSTOMER")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Customer.findAll", query = "SELECT c FROM Customer c"),
    @NamedQuery(name = "Customer.findByCustid", query = "SELECT c FROM Customer c WHERE c.custid = :custid"),
    @NamedQuery(name = "Customer.findByCustname", query = "SELECT c FROM Customer c WHERE c.custname = :custname"),
    @NamedQuery(name = "Customer.findByCusthpnum", query = "SELECT c FROM Customer c WHERE c.custhpnum = :custhpnum"),
    @NamedQuery(name = "Customer.findByCustemail", query = "SELECT c FROM Customer c WHERE c.custemail = :custemail"),
    @NamedQuery(name = "Customer.findByCustpassword", query = "SELECT c FROM Customer c WHERE c.custpassword = :custpassword"),
    @NamedQuery(name = "Customer.findByCustaddress", query = "SELECT c FROM Customer c WHERE c.custaddress = :custaddress"),
    @NamedQuery(name = "Customer.findByCustgender", query = "SELECT c FROM Customer c WHERE c.custgender = :custgender"),
    @NamedQuery(name = "Customer.findByCustactive", query = "SELECT c FROM Customer c WHERE c.custactive = :custactive"),
    @NamedQuery(name = "Customer.findByCustcreateddate", query = "SELECT c FROM Customer c WHERE c.custcreateddate = :custcreateddate"),
    @NamedQuery(name = "Customer.findByCustrecentlogin", query = "SELECT c FROM Customer c WHERE c.custrecentlogin = :custrecentlogin")})
public class Customer implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "CUSTID")
    private String custid;
    @Size(max = 50)
    @Column(name = "CUSTNAME")
    private String custname;
    @Size(max = 12)
    @Column(name = "CUSTHPNUM")
    private String custhpnum;
    @Size(max = 50)
    @Column(name = "CUSTEMAIL")
    private String custemail;
    @Size(max = 20)
    @Column(name = "CUSTPASSWORD")
    private String custpassword;
    @Size(max = 100)
    @Column(name = "CUSTADDRESS")
    private String custaddress;
    @Column(name = "CUSTGENDER")
    private String custgender;
    @Lob
    @Column(name = "CUSTPROFILEPIC")
    private String custprofilepic;
    @Column(name = "CUSTACTIVE")
    private Character custactive;
    @Column(name = "CUSTCREATEDDATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date custcreateddate;
    @Column(name = "CUSTRECENTLOGIN")
    @Temporal(TemporalType.TIMESTAMP)
    private Date custrecentlogin;
    @OneToMany(mappedBy = "custid")
    private List<Carddetails> carddetailsList;
    @OneToMany(mappedBy = "custid")
    private List<Orders> ordersList;

    public Customer() {
    }
public Customer(String custid, String custname, String custhpnum, String custemail, String custpassword, String custaddress) {
        this.custid = custid;
        this.custname = custname;
        this.custhpnum = custhpnum;
        this.custemail = custemail;
        this.custpassword = custpassword;
        this.custaddress = custaddress;
    }

    public Customer(String custid, String custname, String custhpnum, String custemail, String custpassword, String custaddress, String custgender) {
        this.custid = custid;
        this.custname = custname;
        this.custhpnum = custhpnum;
        this.custemail = custemail;
        this.custpassword = custpassword;
        this.custaddress = custaddress;
        this.custgender = custgender;
    }

    public Customer(String custid, String custname, String custhpnum, String custemail, String custpassword, String custaddress, String custgender, String custprofilepic) {
        this.custid = custid;
        this.custname = custname;
        this.custhpnum = custhpnum;
        this.custemail = custemail;
        this.custpassword = custpassword;
        this.custaddress = custaddress;
        this.custgender = custgender;
        this.custprofilepic = custprofilepic;
    }
    public Customer(String custid) {
        this.custid = custid;
    }

    public String getCustid() {
        return custid;
    }

    public void setCustid(String custid) {
        this.custid = custid;
    }

    public String getCustname() {
        return custname;
    }

    public void setCustname(String custname) {
        this.custname = custname;
    }

    public String getCusthpnum() {
        return custhpnum;
    }

    public void setCusthpnum(String custhpnum) {
        this.custhpnum = custhpnum;
    }

    public String getCustemail() {
        return custemail;
    }

    public void setCustemail(String custemail) {
        this.custemail = custemail;
    }

    public String getCustpassword() {
        return custpassword;
    }

    public void setCustpassword(String custpassword) {
        this.custpassword = custpassword;
    }

    public String getCustaddress() {
        return custaddress;
    }

    public void setCustaddress(String custaddress) {
        this.custaddress = custaddress;
    }

    public String getCustgender() {
        return custgender;
    }

    public void setCustgender(String custgender) {
        this.custgender = custgender;
    }

    public String getCustprofilepic() {
        return custprofilepic;
    }

    public void setCustprofilepic(String custprofilepic) {
        this.custprofilepic = custprofilepic;
    }

    public Character getCustactive() {
        return custactive;
    }

    public void setCustactive(Character custactive) {
        this.custactive = custactive;
    }

    public Date getCustcreateddate() {
        return custcreateddate;
    }

    public void setCustcreateddate(Date custcreateddate) {
        this.custcreateddate = custcreateddate;
    }

    public Date getCustrecentlogin() {
        return custrecentlogin;
    }

    public void setCustrecentlogin(Date custrecentlogin) {
        this.custrecentlogin = custrecentlogin;
    }

    @XmlTransient
    public List<Carddetails> getCarddetailsList() {
        return carddetailsList;
    }

    public void setCarddetailsList(List<Carddetails> carddetailsList) {
        this.carddetailsList = carddetailsList;
    }

    @XmlTransient
    public List<Orders> getOrdersList() {
        return ordersList;
    }

    public void setOrdersList(List<Orders> ordersList) {
        this.ordersList = ordersList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (custid != null ? custid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Customer)) {
            return false;
        }
        Customer other = (Customer) object;
        if ((this.custid == null && other.custid != null) || (this.custid != null && !this.custid.equals(other.custid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Customer[ custid=" + custid + " ]";
    }
    
}
